#
# Generated - do not edit!
#
# NOCDDL
#
CND_BASEDIR=`pwd`
# EXT_UART configuration
CND_ARTIFACT_DIR_EXT_UART=dist/EXT_UART/production
CND_ARTIFACT_NAME_EXT_UART=drone_mb_escboard.X.production.hex
CND_ARTIFACT_PATH_EXT_UART=dist/EXT_UART/production/drone_mb_escboard.X.production.hex
# X2CScope configuration
CND_ARTIFACT_DIR_X2CScope=dist/X2CScope/production
CND_ARTIFACT_NAME_X2CScope=drone_mb_escboard.X.production.hex
CND_ARTIFACT_PATH_X2CScope=dist/X2CScope/production/drone_mb_escboard.X.production.hex
