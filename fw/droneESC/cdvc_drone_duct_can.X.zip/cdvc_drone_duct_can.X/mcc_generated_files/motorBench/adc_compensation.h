/**
 * adc_compensation.h
 * 
 * ADC compensation
 * 
 * Component: ADC compensation
 */

/* *********************************************************************
 *
 * Motor Control Application Framework
 * R9/RC31 (commit 132024, build on 2026 Feb 13)
 *
 * (c) 2017 - 2023 Microchip Technology Inc. and its subsidiaries. You may use
 * this software and any derivatives exclusively with Microchip products.
 *
 * This software and any accompanying information is for suggestion only.
 * It does not modify Microchip's standard warranty for its products.
 * You agree that you are solely responsible for testing the software and
 * determining its suitability.  Microchip has no obligation to modify,
 * test, certify, or support the software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES,
 * WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE,
 * INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY,
 * AND FITNESS FOR A PARTICULAR PURPOSE, OR ITS INTERACTION WITH
 * MICROCHIP PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY
 * APPLICATION.
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL,
 * PUNITIVE, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF
 * ANY KIND WHATSOEVER RELATED TO THE USE OF THIS SOFTWARE, THE
 * motorBench(R) DEVELOPMENT SUITE TOOL, PARAMETERS AND GENERATED CODE,
 * HOWEVER CAUSED, BY END USERS, WHETHER MICROCHIP'S CUSTOMERS OR
 * CUSTOMER'S CUSTOMERS, EVEN IF MICROCHIP HAS BEEN ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGES OR THE DAMAGES ARE FORESEEABLE. TO THE
 * FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL
 * CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT
 * OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS
 * SOFTWARE.
 *
 * MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF
 * THESE TERMS.
 *
 * *****************************************************************************/

#ifndef MCAF_ADC_COMPENSATION_H 
#define MCAF_ADC_COMPENSATION_H 

#include "units.h"
#include "adc_compensation_types.h"
#include "system_state.h"

#ifdef __cplusplus
extern "C" {
#endif

#if MCAF_ADC_GAIN_COMPENSATION_ENABLED
/**
 * Initializes ADC Gain Compensator
 *
 * @param pcompensator ADC Gain Compensator state
*/
void MCAF_ADCGainCompInit(MCAF_ADC_GAIN_COMPENSATOR *pcompensator);

/**
 * Resets ADC gain compensator 
 *
 * @param pcompensator ADC Gain Compensator state
 */
inline static void MCAF_ADCGainCompRestart(MCAF_ADC_GAIN_COMPENSATOR *pcompensator)
{
    pcompensator->sampleCount = 0;
    pcompensator->ready = false;
    pcompensator->success = true;
}

/**
 * Returns whether 33A ADC gain compensation is ready
 *
 * @param pcompensator ADC gain compensation data structure
 * @return true if ADC gain compensation is ready
 */
inline static bool MCAF_ADCGainCompReady(const MCAF_ADC_GAIN_COMPENSATOR *pcompensator)
{
   return pcompensator->ready;
}

/**
 * Returns whether the 33A ADC gain compensation routine is successful
 *
 * @param pcompensator ADC gain compensation data structure
 * @return true if ADC gain compensation results are within limits
 */
inline static bool MCAF_ADCGainCompSuccessful(const MCAF_ADC_GAIN_COMPENSATOR *pcompensator)
{
   return pcompensator->success;
}

/** 
 * ADC gain compensation for 33A devices
 *
 * @param pmotor motor data
 */
void MCAF_ADCGainCompensationStep(MCAF_MOTOR_DATA *pmotor);
#endif

/**
 * Returns whether the ADC initialization is ready
 *
 * @param pmotor motor data structure
 * @return true if ADC initialization is ready
 */
inline static bool MCAF_ADCInitializationReady(const MCAF_MOTOR_DATA *pmotor)
{
    return pmotor->adcCompensation.currentCalibration.ready;
}

/**
 * Returns whether ADC current offset calibration is ready
 *
 * @param pcompensator ADC current offset calibration data structure
 * @return true if ADC current offset calibration results are within limits
 */
inline static bool MCAF_ADCCurrentOffsetCalibrationSuccessful(const MCAF_CURRENT_CALIBRATION *pcal)
{
    return pcal->success;
}

/**
 * Initializes ADC current offset calibration
 *
 * @param pinit ADC current offset initialization state
 */
void MCAF_ADCCurrentOffsetCalibrationInit(MCAF_CURRENT_CALIBRATION *pcal);

/**
 * Manage ADC readings
 * 
 * @param pmotor motor data
 */
void MCAF_ADCRead(MCAF_MOTOR_DATA *pmotor);

/**
 * Manage ADC readings that are not time-critical
 * 
 * @param pmotor motor data
 */
void MCAF_ADCReadNonCritical(MCAF_MOTOR_DATA *pmotor);



#ifdef __cplusplus
}
#endif

#endif /* MCAF_ADC_COMPENSATION_H */
