/*
� [2026] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
 */
#include "mcc_generated_files/motorBench/mcaf_main.h"
#include "mcc_generated_files/system/system.h"
#include "mcc_generated_files/can/can1.h"

//#include "arm_can.h"
#include "APL_CAN.h"
#include "system/pins.h"
#include <xc.h>

struct CAN_MSG_OBJ sCanTramsmitBuffer;
volatile uint8_t au8Array[8U];

volatile uint16_t u16Ticker;

void MCAPI_AdcIsrProlog(void)
{
    u16Ticker++;
}

/*
    Main application
 */

int main(void)
{
    SYSTEM_Initialize();
    MCAF_MainInit();

    APL_ATA6563Enable();

    while (1)
    {
        MCAF_MainLoop();
        ARM_CAN_Tasks(); /* update arm_angle from received CAN messages */

        if (u16Ticker > 200U) // every 10ms
        {

            /* setup transmission information */
            sCanTramsmitBuffer.msgId = 0x555u;
            sCanTramsmitBuffer.field.dlc = DLC_8;
            sCanTramsmitBuffer.field.brs = CAN_NON_BRS_MODE;
            sCanTramsmitBuffer.field.formatType = CAN_2_0_FORMAT;
            sCanTramsmitBuffer.field.frameType = CAN_FRAME_DATA;
            sCanTramsmitBuffer.field.idType = CAN_FRAME_STD;
            sCanTramsmitBuffer.data = (uint8_t*) & au8Array;

            CAN1_Transmit(CAN1_TXQ, (struct CAN_MSG_OBJ*) &sCanTramsmitBuffer);
        }
    }
}